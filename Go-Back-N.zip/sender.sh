#!/bin/bash

java sender "$1" $2 $3 "$4"