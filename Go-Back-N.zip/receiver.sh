#!/bin/bash

java receiver "$1" $2 $3 "$4"